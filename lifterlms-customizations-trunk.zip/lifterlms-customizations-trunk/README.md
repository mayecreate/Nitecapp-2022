LifterLMS Customizations
------------------------

See [https://lifterlms.com/docs/how-do-i-add-custom-code-to-lifterlms-or-lifterlms-launchpad/](https://lifterlms.com/docs/how-do-i-add-custom-code-to-lifterlms-or-lifterlms-launchpad/)