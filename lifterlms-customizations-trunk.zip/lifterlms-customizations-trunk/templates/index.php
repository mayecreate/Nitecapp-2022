<?php
/**
 * Copy templates from lifterlms/templates and add them
 * to this directory to replace the default LifterLMS Templates
 * for more information see documentation at
 * https://lifterlms.com/docs/lifterlms-templates/
 *
 * You must also uncomment a line in the "lifterlms-customizations.php" file
 * See comment for the function llms_customizations_overrides_directory()
 * in that file
 */