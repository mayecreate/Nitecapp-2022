<?php
/**
 * Lesson Progression actions
 * Mark Complete & Mark Incomplete buttons
 * Take Quiz Button when quiz attached
 *
 * @since 1.0.0
 * @since 3.33.0 Only render on lesson post types.
 * @version 3.33.0
 */
if (is_admin()) { ?>
	<p class="center" style="color: #FF0004"><strong>============== Mark Complete Button Goes Here ==============</strong></p>
<?php } else {
defined( 'ABSPATH' ) || exit;

global $post, $current_user;

$lesson = llms_get_post( $post );
if ( ! $lesson || ! is_a( $lesson, 'LLMS_Lesson' ) ) {
	return;
}

if(current_user_can('care-giver') || current_user_can('administrator') || current_user_can('instructors_assistant')) {
	$current_selected_user = get_field("current_selected_user", 'user_'.$current_user->ID);
	if (($current_selected_user == 'none') || ($current_selected_user == '') || ($current_selected_user == '0')) {
		$current_selected_user_ID = get_current_user_id();
	} elseif($current_selected_user_ID) {
		$current_selected_user_ID = $current_selected_user;
	} else {
		$current_selected_user_ID = get_current_user_id();
	} 
} else {
	$current_selected_user_ID = get_current_user_id();
}

if ( ! llms_is_user_enrolled( $current_selected_user_ID, $lesson->get( 'parent_course' ) ) && ! current_user_can( 'edit_post', $lesson->get( 'id' ) ) ) {
	return;
}

if(current_user_can('care-giver') || current_user_can('administrator') || current_user_can('instructors_assistant')) {
	$current_selected_user = get_field("current_selected_user", 'user_'.$current_user->ID);
	if (($current_selected_user == 'none') || ($current_selected_user == '') || ($current_selected_user == '0')) {
		$student = llms_get_student( get_current_user_id() );
		$complete_text = 'Mark Complete';
		$incomplete_text = 'Mark Incomplete';
	} elseif($current_selected_user) {
		$student = llms_get_student( $current_selected_user );
		$current_selected_user_name = get_display_name($current_selected_user);
		$complete_text = 'Mark Complete for '. $current_selected_user_name .'';
		$incomplete_text = 'Mark Incomplete for '. $current_selected_user_name .'';
	} else {
		$student = llms_get_student( get_current_user_id() );
		$complete_text = 'Mark Complete';
		$incomplete_text = 'Mark Incomplete';
	} 
} else {
	$current_selected_user = get_current_user_id();
	$student = llms_get_student( get_current_user_id() );
	$complete_text = 'Mark Complete';
	$incomplete_text = 'Mark Incomplete';
}

?>

<div class="clear"></div>
<?php if(current_user_can('care-giver') || current_user_can('administrator') || current_user_can('instructors_assistant')) { ?>
<div class="llms-lesson-button-wrapper wrapper_<?php echo $current_selected_user; ?> caregiver_wrapper">
<?php } else { ?>
<div class="llms-lesson-button-wrapper wrapper_<?php echo $current_selected_user; ?>">
<?php } ?>

	<?php do_action( 'llms_before_lesson_buttons', $lesson, $student ); ?>
	<?php //if ( $student->is_complete( $lesson->get( 'id' ), 'lesson' ) ) { echo 'COMPLETE'; } else { echo 'This is not COMPLETE'; } ?>
	<?php if ( $student->is_complete( $lesson->get( 'id' ), 'lesson' ) ) { ?>

		<?php if ( llms_show_mark_complete_button( $lesson ) ) { ?>

			<?php echo apply_filters( 'llms_lesson_complete_text', __( 'Lesson Complete', 'lifterlms' ) ); ?>
			<?php do_action( 'llms_after_lesson_complete_text', $lesson ); ?>

			<?php if ( 'yes' === get_option( 'lifterlms_retake_lessons', 'no' ) || apply_filters( 'lifterlms_retake_lesson_' . $lesson->get( 'parent_course' ), false ) ) { ?>

				<form action="" class="llms-incomplete-lesson-form" method="POST" name="mark_incomplete">

					<?php do_action( 'lifterlms_before_mark_incomplete_lesson' ); ?>
					<input type="hidden" name="mark-incomplete" value="<?php echo esc_attr( $lesson->get( 'id' ) ); ?>" />
					<input type="hidden" name="action" value="mark_incomplete" />
					<?php wp_nonce_field( 'mark_incomplete' ); ?>

					<?php
					llms_form_field(
						array(
							'columns'     => 12,
							'classes'     => 'llms-button-secondary auto button',
							'id'          => 'llms_mark_incomplete',
							'value'       => apply_filters( 'lifterlms_mark_lesson_incomplete_button_text', __( $incomplete_text, 'lifterlms' ), $lesson ),
							'last_column' => true,
							'name'        => 'mark_incomplete',
							'required'    => false,
							'type'        => 'submit',
						)
					);
					?>

					<?php do_action( 'lifterlms_after_mark_incomplete_lesson' ); ?>

				</form>

			<?php } ?>

		<?php } ?>

	<?php } else { ?>

		<?php if ( llms_show_mark_complete_button( $lesson ) ) { ?>

			<form action="" class="llms-complete-lesson-form" method="POST" name="mark_complete">

				<?php do_action( 'lifterlms_before_mark_complete_lesson' ); ?>
				
				<input type="hidden" name="mark-complete" value="<?php echo esc_attr( $lesson->get( 'id' ) ); ?>" />
				<input type="hidden" name="action" value="mark_complete" />
				<?php wp_nonce_field( 'mark_complete' ); ?> 

				<?php
				llms_form_field(
					array(
						'columns'     => 12,
						'classes'     => 'llms-button-primary auto button',
						'id'          => 'llms_mark_complete',
						'value'       => apply_filters( 'lifterlms_mark_lesson_complete_button_text', __( $complete_text, 'lifterlms' ), $lesson ),
						'last_column' => true,
						'name'        => 'mark_complete',
						'required'    => false,
						'type'        => 'submit',
					)
				);
				?>

				<?php do_action( 'lifterlms_after_mark_complete_lesson' ); ?>

			</form>

		<?php } ?>

	<?php } ?>
	<?php if(current_user_can('care-giver') || current_user_can('administrator') || current_user_can('instructors_assistant')) { ?>
		<h5 class="center">Need to change which user you're marking the lesson complete for?</h5>
	<?php } ?>
	<?php if(current_user_can('care-giver')) { ?>
		<a href="<?php bloginfo('url'); ?>/caregiver-home/" class="btn-mayecreate center">Click Here to Change Your Selected User</a>
	<?php } elseif(current_user_can('instructors_assistant')) { ?>
		<a href="<?php bloginfo('url'); ?>/moderator-home/" class="btn-mayecreate center">Click Here to Change Your Selected User</a>
	<?php } elseif(current_user_can('administrator')) { ?>
		<a href="<?php bloginfo('url'); ?>/admin-home/" class="btn-mayecreate center">Click Here to Change Your Selected User</a>
	<?php } ?>

	<?php if ( llms_show_take_quiz_button( $lesson ) ) : ?>

		<?php do_action( 'llms_before_start_quiz_button' ); ?>

		<a class="llms-button-action auto button" id="llms_start_quiz" href="<?php echo get_permalink( $lesson->get( 'quiz' ) ); ?>">
			<?php echo apply_filters( 'lifterlms_start_quiz_button_text', __( 'Take Quiz', 'lifterlms' ), $lesson->get( 'quiz' ), $lesson ); ?>
		</a>

		<?php do_action( 'llms_after_start_quiz_button' ); ?>

	<?php endif; ?>

	<?php do_action( 'llms_after_lesson_buttons', $lesson, $student ); ?>

</div>
<?php } ?>
